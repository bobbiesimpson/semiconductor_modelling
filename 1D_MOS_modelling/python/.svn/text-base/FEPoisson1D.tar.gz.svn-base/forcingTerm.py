# 	the forcing term (ie the RHS of Poisson's equation) is required for calculation
#	of various matrix terms. 

from math import exp, cos, sin

def E(psi, q, epsilon, phi_n, phi_p, kT, ni, Na):
	E = - q  * ( - ni * exp( q * ( psi - phi_n ) / kT )  + ni * exp( q * ( phi_p - psi ) / kT ) - Na )
	temp = exp(0.5*psi) + psi
	return  E
						  
def Ederiv(psi, q, epsilon, phi_n, phi_p, kT, ni, Na):
	Ederiv = - q  * ( - ni * exp( q * ( psi - phi_n ) / kT ) * q / kT + ni * exp( q * ( phi_p - psi ) / kT ) * - q / kT )
	temp =   0.5 * exp(psi) + 1
	return Ederiv


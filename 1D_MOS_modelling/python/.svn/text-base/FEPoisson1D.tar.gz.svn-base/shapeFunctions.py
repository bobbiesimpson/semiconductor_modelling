# 	shape functions

def N1(xi):
	return 0.5 * ( 1.0 - xi )
	
def N2(xi):
	return 0.5 * ( 1.0 + xi )